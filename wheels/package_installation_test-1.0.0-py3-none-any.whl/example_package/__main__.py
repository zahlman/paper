from . import __version__, main


if __name__ == '__main__': # should always be true, but still
    main()
